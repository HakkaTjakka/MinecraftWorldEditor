./cross2.sh --build-ffmpeg-static=y --build-ffmpeg-shared=n --disable-nonfree=n --compiler-flavors=win64 --enable-gpl=y
