-----------------------------------------------------------------------------
File  : 'Readme.txt' - Readme for IrfanView PlugIns
Author: Irfan Skiljan
E-Mail: irfanview@gmx.net
WWW   : http://www.irfanview.com
-----------------------------------------------------------------------------



- How to install this IrfanView plugin?

  1) If you download the self installing plugins: irfanview_plugins_XXX.exe,
     just start the file. Done.

  otherwise:

  1) Find your IrfanView directory

  2) Unzip all files from the ZIP file into the "PlugIns" subdirectory

  3) Done


