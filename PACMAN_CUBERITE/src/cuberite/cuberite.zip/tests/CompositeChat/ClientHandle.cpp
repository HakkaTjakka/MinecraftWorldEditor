
// ClientHandle.cpp

// Mocks the cClientHandle class used by the tests

#include "Globals.h"
#include "ClientHandle.h"





AString cClientHandle::FormatMessageType(bool a_ShouldShowPrefixes, eMessageType a_MsgType, const AString & a_AdditionalData)
{
	return "<FormatMessageType mocked>";
}




