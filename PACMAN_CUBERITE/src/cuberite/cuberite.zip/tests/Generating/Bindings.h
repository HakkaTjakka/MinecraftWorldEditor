
// Bindings.h

// Dummy include file needed for LuaState to compile successfully




struct lua_State;

int tolua_AllToLua_open(lua_State * a_LuaState);




