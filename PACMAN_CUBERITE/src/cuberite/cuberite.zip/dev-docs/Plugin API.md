# Looking for the API documentation for Lua plugins?

See the [cuberite website](api.cuberite.org) or browse the [source](https://github.com/cuberite/cuberite/tree/master/Server/Plugins/APIDump).
