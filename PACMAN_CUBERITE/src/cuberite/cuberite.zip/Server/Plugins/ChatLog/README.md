ChatLog
=======

A Chat Log plugin for Cuberite.

This work is Copyright of the [Cuberite Developers](https://github.com/cuberite/Cuberite/blob/master/CONTRIBUTORS)
