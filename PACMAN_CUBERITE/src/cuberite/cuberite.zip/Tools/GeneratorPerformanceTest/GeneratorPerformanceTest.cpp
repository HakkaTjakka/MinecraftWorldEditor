
#include "Globals.h"
#include "ChunkGenerator.h"

int main(int argc, char * argv[])
{
	cChunkGenerator Generator = cChunkGenerator();
}
