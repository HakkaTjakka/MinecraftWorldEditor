GrownBiomeGenVisualiser
----

This project aims to provide the visualisation of "Grown" biome generator used in Cuberite. It uses the generator to generate several bitmaps showcasing the generator; these images are then used in the generator documentation ($/docs/Generator.html)
