
// Globals.h

// Used for precompiled header generation





#pragma once

#include "../../src/Globals.h"

/*
// System headers:
#include "targetver.h"
#include <stdio.h>

// STL headers:
#include <vector>
#include <list>
#include <map>
#include <string>

// Common:
#include "../src/StringUtils.h"
#include "../src/OSSupport/File.h"
*/

// Libraries:
#include "expat/expat.h"




